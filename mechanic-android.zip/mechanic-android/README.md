# MechAnIc Android app

The MechAnIc web app wrapped as a native Android app with Capacitor. The web code is in `www/index.html`.

## Get the APK without installing anything (GitHub)
1. Create a free GitHub repository and upload everything in this folder, including the hidden `.github` folder.
2. Open the repository's **Actions** tab, choose **Build Android APK**, and press **Run workflow**.
3. When it finishes (about 5 to 10 minutes), open the run and download **MechAnIc-debug-apk**.
4. Unzip it, copy `app-debug.apk` to your phone, and open it. Android will ask you to allow installs from this source.

## Or build it yourself
Needs Node 20, JDK 21 and Android Studio.
```
npm install
npx cap add android
# add RECORD_AUDIO, MODIFY_AUDIO_SETTINGS and CAMERA permissions to android/app/src/main/AndroidManifest.xml
npx cap sync android
npx cap open android      # then Build > Build APK in Android Studio
```

## Live AI
Without a server the app shows labeled sample answers. Deploy the MechAnIc backend, then in the app open **Settings > Server connection**, enter its HTTPS address and save. On the server set:
```
ALLOWED_ORIGINS=https://localhost
```
The app runs from `https://localhost` inside the phone, so the server must allow that origin. Plain `http://` servers won't work.

## Notes
- This builds a **debug** APK for testing. Publishing to Google Play needs a signed release build, an app icon and a store listing.
- The default Capacitor icon is used. Replace it in Android Studio or with `@capacitor/assets`.
- Vehicles and chats are stored on the phone only.
