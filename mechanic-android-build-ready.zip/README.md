# MechAnIc Android app

MechAnIc is packaged as a native Android app with Capacitor. The web application lives in `www/` and the native Android project is generated from the Capacitor configuration.

## Build an APK with GitHub Actions

This repository is intentionally kept lightweight and does **not** commit the generated `android/` directory. The workflow creates it from the pinned Capacitor Android dependency, adds the camera/microphone permissions, synchronizes `www/`, and builds a debug APK.

1. Upload this folder to a GitHub repository.
2. Open **Actions** → **Build Android APK**.
3. Choose **Run workflow**.
4. Download the `MechAnIc-debug-apk` artifact from the completed run.

The workflow uses Node.js 20 and JDK 21, matching the current Capacitor 7 Android toolchain requirements.

## Local build

Requirements:
- Node.js 20+
- JDK 21
- Android SDK / Android Studio

Run:

```bash
npm install
npx cap add android
node scripts/prepare-android.mjs
npx cap sync android
cd android
./gradlew assembleDebug
```

The APK is generated at:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## App permissions

The native project requests:
- Camera, for vehicle/photo diagnosis.
- Microphone, for recording vehicle sounds.
- Audio settings, for microphone capture behavior.

Android still controls runtime permission prompts on the device.

## Live AI backend

Without a backend, the web app can run in sample mode. To use live AI, open **Settings → Server connection** and provide the HTTPS address of the MechAnIc backend. The app normalizes the address to `/api/chat`.

The Capacitor Android WebView uses the `https` scheme, so the production backend should be HTTPS and configured to accept requests from the app's WebView origin (`https://localhost`).

## Release APK

The included workflow creates a debug APK for testing. A Google Play release requires a signed release build, release keystore, application icon/assets, versioning, and Play Console metadata.
