import fs from 'node:fs';

const manifest = 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(manifest)) {
  throw new Error(`AndroidManifest.xml not found at ${manifest}. Run "npx cap add android" first.`);
}

let xml = fs.readFileSync(manifest, 'utf8');
const permissions = [
  'android.permission.CAMERA',
  'android.permission.RECORD_AUDIO',
  'android.permission.MODIFY_AUDIO_SETTINGS'
];
for (const permission of permissions) {
  const tag = `    <uses-permission android:name="${permission}" />`;
  if (!xml.includes(`android:name="${permission}"`)) {
    xml = xml.replace('</manifest>', `${tag}\n</manifest>`);
  }
}
fs.writeFileSync(manifest, xml);
console.log('Android permissions prepared:', permissions.join(', '));
